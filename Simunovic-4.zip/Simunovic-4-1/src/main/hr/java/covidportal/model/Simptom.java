package main.hr.java.covidportal.model;

import main.hr.java.covidportal.enumeracija.VrijednostiSimptoma;

/**
 * Klasa Simptom za kreiranje instance simptoma
 * nasljeđuje ImenovaniEntitet i njenu varijablu naziv
 */
public class Simptom extends ImenovaniEntitet {
    private VrijednostiSimptoma vrijednost;
    private String sifra;

    public Simptom(String naziv, VrijednostiSimptoma vrijednost, String sifra) {
        super(naziv);
        this.vrijednost = vrijednost;
        this.sifra = sifra;
    }

    public String getSifra() {
        return sifra;
    }

    public void setSifra(String sifra) {
        this.sifra = sifra;
    }

    public VrijednostiSimptoma getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(VrijednostiSimptoma vrijednost) {
        this.vrijednost = vrijednost;
    }
}
