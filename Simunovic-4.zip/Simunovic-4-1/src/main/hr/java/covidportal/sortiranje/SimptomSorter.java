package main.hr.java.covidportal.sortiranje;

import main.hr.java.covidportal.model.Simptom;
import java.util.Comparator;

public class SimptomSorter implements Comparator<Simptom> {
    @Override
    public int compare(Simptom s1, Simptom s2) {
        Comparator<Simptom> comparator = Comparator.comparing(simptom -> simptom.getNaziv());
        if (s1.getNaziv().compareTo(s2.getNaziv())<0) {
            return 1;
        } else if (s1.getNaziv().compareTo(s2.getNaziv()) > 0) {
            return -1;
        } else {
            return 0;
        }
    }
}
